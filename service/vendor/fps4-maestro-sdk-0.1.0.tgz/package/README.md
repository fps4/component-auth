# maestro managed-product SDK — TypeScript (`sdk-js/`)

The TypeScript client a deployed product installs to implement the EP-06 platform contracts from
**install + config**, instead of hand-rolling the integration (US-0066). It is the JS/TS sibling of the
Python [`sdk/`](../sdk/README.md) — both are ergonomic layers over
[`standards/managed-product-platform.yaml`](../standards/managed-product-platform.yaml) (US-0065). The
**wire contract is first-class**, so this SDK is a convenience, not a requirement.

Built for Node ≥ 20 and modern bundlers (Next.js / Vite / webpack). The core is framework-agnostic;
React and Next.js helpers live under the `@fps4/maestro-sdk/react` and `@fps4/maestro-sdk/next` subpath
exports.

## What it does (parity with the Python SDK)

| Surface | Method(s) | Story |
|---|---|---|
| Outbound channel (long-poll + ack) | `poll`, `ackDelivered`, `ackRead`, `pump(handlers)` | US-0060 |
| Feedback prompt → response | (receive via `pump`) + `submitFeedbackResponse` | US-0061 |
| Announcements (receive + read-ack) | (receive via `pump`) + `ackRead` | US-0062 |
| Feature-request submission | `submitFeatureRequest` | US-0063 |
| Incident-report submission | `submitIncidentReport` | US-0064 |
| Heartbeat | `submitHeartbeat` | US-0070 |
| Telemetry export (golden-signal time-series) | `submitTelemetry` | US-0076 |
| Log shipping (content-boundary-gated, redacted) | `shipLogs` | US-0081 |

## Two design rules (same as the Python SDK)

- **UI-agnostic.** `pump(handlers)` hands each pushed message to a product-supplied
  `(envelope) => void` — the product draws the bell / the inline prompt / the banner. No rendering
  lives in the SDK.
- **Degrade safely when maestro is unreachable.** Outbound rendering no-ops (`poll` resolves to `[]`);
  inbound submissions are **queued** and retried by `flush()`. The host product never crashes because
  the platform is down.

It honours the **content boundary** (ADR-0027 §2) sender-side: under `reference_only` it does not even
send user-authored free text (the receiver re-asserts the boundary as defence in depth), and it always
length-bounds it.

## Install

```bash
npm install @fps4/maestro-sdk
```

`react` is an optional peer dependency (only needed for the `/react` helpers).

## Usage — core client

```ts
import { MaestroProductClient } from '@fps4/maestro-sdk';

const client = new MaestroProductClient({
  productId: 'copilot',
  deploymentId: 'prod-aws',                 // THIS instance (ADR-0035) — each deployment has its own
                                            //   product_runtime identity; calls route under
                                            //   /api/products/copilot/deployments/prod-aws/…
  tokenProvider: getRuntimeJwt,             // returns the product_runtime component-auth JWT (sync/async)
  baseUrl: 'https://maestro.example',       // or pass `transport` for tests
  contentBoundary: 'user_authored_allowed', // matches this deployment's register policy
});

// render pushed messages (call on a timer / long-poll loop)
await client.pump({
  announcement: renderBellItem,
  user_feedback_request: renderInlinePrompt,
});

// submit
await client.submitFeedbackResponse('corr-123', { rating: 1, free_text: 'loved it' });
await client.submitFeatureRequest('export chat as PDF', { user_id: 'u-42' });
await client.submitHeartbeat('ok', { uptime_seconds: 3600, p95_latency_ms: 220 });
await client.submitTelemetry('ok', { p95_latency_ms: 210, errors: { '5xx': 2 } });
```

Transport is injected (a `Transport`), so the client is unit-testable with no sockets; the default
`fetchTransport` is built on the global `fetch`. `client.info()` reports the standard + per-contract
versions this build implements.

## Usage — Next.js / Node server

Wire the emit-on-timer loop into Next's `instrumentation.ts` so the long-lived server pushes heartbeat +
telemetry on a cadence (default 60s + jitter):

```ts
// instrumentation.ts
export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;
  const { MaestroProductClient } = await import('@fps4/maestro-sdk');
  const { startManagedProductEmitter } = await import('@fps4/maestro-sdk/next');

  const base = process.env.MAESTRO_API_URL;
  if (!base) return; // not configured → the SDK stays inert (safe default)

  const client = new MaestroProductClient({
    productId: process.env.MAESTRO_PRODUCT_ID!,
    deploymentId: process.env.MAESTRO_DEPLOYMENT_ID!,
    tokenProvider: () => process.env.MAESTRO_RUNTIME_JWT!,
    baseUrl: base,
    contentBoundary: 'reference_only',
  });

  startManagedProductEmitter(client, () => ({
    status: 'ok',
    heartbeat: { uptime_seconds: Math.round(process.uptime()) },
    telemetry: { /* your rolling golden signals */ },
  }));
}
```

Expose the same snapshot as a health route (`patterns.yaml`):

```ts
// app/health/route.ts
import { createHealthRoute } from '@fps4/maestro-sdk/next';
export const GET = createHealthRoute(() => ({ status: 'ok' }));
```

## Usage — React

Drive the outbound channel from a client component (the SDK still never renders — you do):

```tsx
import { useMaestroPump } from '@fps4/maestro-sdk/react';

useMaestroPump(client, {
  announcement: (env) => showBanner(env),
  user_feedback_request: (env) => showPrompt(env),
}, { intervalMs: 30_000 });
```

## Scripts

```bash
npm run typecheck   # tsc --noEmit
npm test            # vitest
npm run build       # tsup → dist/ (ESM + .d.ts, three subpath entries)
```

## Parity note

This SDK mirrors `sdk/` (Python) method-for-method and is tested against the same contract behaviour
(safe-degrade, the sender-side content boundary, pump auto-ack, the floor-safe heartbeat/telemetry). Keep
the two in lockstep when `standards/managed-product-platform.yaml` revs.
